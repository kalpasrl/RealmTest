﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RealmTest
{
    internal interface ISubClass
    {
        int MyKey { get; set; }
        string MyProperty1 { get; set; }
        string MyProperty2 { get; set; }
        string MyProperty3 { get; set; }
        string MyProperty4 { get; set; }
        string MyProperty5 { get; set; }
    }
}
